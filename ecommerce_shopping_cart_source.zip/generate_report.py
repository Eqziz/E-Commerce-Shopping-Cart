import os
import sys
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether, Preformatted
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfgen import canvas

class NumberedCanvas(canvas.Canvas):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._saved_page_states = []

    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()

    def save(self):
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_number(num_pages)
            super().showPage()
        super().save()

    def draw_page_number(self, page_count):
        self.saveState()
        self.setFont("Helvetica", 9)
        self.setFillColor(colors.HexColor("#4A5568"))
        
        # Header (pages > 1)
        if self._pageNumber > 1:
            self.drawString(54, 11 * inch - 36, "Software Design Patterns — Final Project Report | E-Commerce Shopping Cart")
            self.setStrokeColor(colors.HexColor("#CBD5E1"))
            self.setLineWidth(0.5)
            self.line(54, 11 * inch - 42, 8.5 * inch - 54, 11 * inch - 42)

        # Footer
        page_text = f"Page {self._pageNumber} of {page_count}"
        self.drawRightString(8.5 * inch - 54, 36, page_text)
        self.drawString(54, 36, "Confidential — Software Design Patterns Final Defense")
        self.setStrokeColor(colors.HexColor("#CBD5E1"))
        self.setLineWidth(0.5)
        self.line(54, 48, 8.5 * inch - 54, 48)
        self.restoreState()

def create_report(output_filename="Ecommerce_Shopping_Cart_Report.pdf"):
    doc = SimpleDocTemplate(
        output_filename,
        pagesize=letter,
        leftMargin=54,
        rightMargin=54,
        topMargin=54,
        bottomMargin=54
    )

    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=24,
        leading=28,
        textColor=colors.HexColor("#1A365D"),
        spaceAfter=8
    )

    subtitle_style = ParagraphStyle(
        'DocSubTitle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=12,
        leading=16,
        textColor=colors.HexColor("#4A5568"),
        spaceAfter=20
    )

    h1_style = ParagraphStyle(
        'H1',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=16,
        leading=20,
        textColor=colors.HexColor("#1A365D"),
        spaceBefore=14,
        spaceAfter=8,
        keepWithNext=True
    )

    h2_style = ParagraphStyle(
        'H2',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=12,
        leading=16,
        textColor=colors.HexColor("#2B6CB0"),
        spaceBefore=10,
        spaceAfter=4,
        keepWithNext=True
    )

    body_style = ParagraphStyle(
        'Body',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=10,
        leading=14,
        textColor=colors.HexColor("#2D3748"),
        spaceAfter=8
    )

    code_style = ParagraphStyle(
        'CodeStyle',
        parent=styles['Code'],
        fontName='Courier',
        fontSize=8,
        leading=10,
        textColor=colors.HexColor("#1A202C")
    )

    story = []

    # Title & Metadata
    story.append(Paragraph("E-Commerce Shopping Cart System", title_style))
    story.append(Paragraph("Software Design Patterns Course — Final Project Defense Report", subtitle_style))

    meta_data = [
        [Paragraph("<b>Topic:</b>", body_style), Paragraph("E-Commerce Shopping Cart with Pluggable GoF Patterns", body_style)],
        [Paragraph("<b>Target Stack:</b>", body_style), Paragraph("Java 21 LTS | Clean Architecture | SOLID Principles", body_style)],
        [Paragraph("<b>Team Lead:</b>", body_style), Paragraph("Nodir Mukhammedov (GitHub: <code>Eqziz</code>)", body_style)],
        [Paragraph("<b>Engineers:</b>", body_style), Paragraph("Mereilim Baktiyarova (<code>baktiyarovamereilim-lang</code>)<br/>Zhansaya Sarsenbay (<code>AinurSarsenbai</code>)", body_style)],
        [Paragraph("<b>Repository:</b>", body_style), Paragraph("<code>https://github.com/Eqziz/E-Commerce-Shopping-Cart</code>", body_style)]
    ]
    t_meta = Table(meta_data, colWidths=[110, 394])
    t_meta.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor("#F7FAFC")),
        ('BOX', (0,0), (-1,-1), 1, colors.HexColor("#E2E8F0")),
        ('INNERGRID', (0,0), (-1,-1), 0.5, colors.HexColor("#EDF2F7")),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
    ]))
    story.append(t_meta)
    story.append(Spacer(1, 15))

    # 1. INTRODUCTORY PART
    story.append(Paragraph("1. Introductory Part", h1_style))
    story.append(Paragraph(
        "Modern electronic commerce systems demand modularity, maintainability, and high extensibility. "
        "As retail requirements evolve, platforms must support polymorphic catalog hierarchies, customizable products, "
        "dynamic promotional strategies, real-time inventory notifications, and third-party payment gateways without "
        "resorting to brittle monolithic architectures. This project fulfills all requirements specified in the "
        "Software Design Patterns Final Defense criteria by implementing seven distinct Gang of Four (GoF) patterns "
        "collaboratively developed across three student software engineers.",
        body_style
    ))

    # Contribution Table
    story.append(Paragraph("Pattern Allocation & Contribution Matrix", h2_style))
    matrix_data = [
        ["Pattern", "Type", "Assigned Developer", "Core Responsibility in Project"],
        ["Builder", "Creational", "Eqziz", "Assembles custom hardware rigs (CPU, RAM, GPU, OS) with step-by-step cost accumulation."],
        ["Factory Method", "Creational", "AinurSarsenbai", "Instantiates category products (Electronics, Apparel, Books, Digital) with specific tax & logistics."],
        ["Observer", "Behavioral", "baktiyarovamereilim-lang", "Broadcasts real-time stock updates, low-stock warnings, and price drop deals to subscribers."],
        ["Strategy", "Behavioral", "Eqziz", "Calculates runtime discounts (Percentage, Flat, Loyalty Tiers, BOGO) swappable at checkout."],
        ["Decorator", "Structural", "baktiyarovamereilim-lang", "Dynamically adds services (Gift Wrapping, 2-Year Warranty, Express Shipping, Fragile Handling)."],
        ["Adapter", "Structural", "AinurSarsenbai", "Bridges external payment gateways (Stripe, PayPal, Crypto) to unified internal interface."],
        ["Facade", "Structural", "AinurSarsenbai", "Orchestrates stock verification, discount evaluation, payment, and receipt generation in one entry point."]
    ]
    t_matrix = Table(matrix_data, colWidths=[80, 65, 115, 244])
    t_matrix.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#2B6CB0")),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,0), 9),
        ('BOTTOMPADDING', (0,0), (-1,0), 6),
        ('BACKGROUND', (0,1), (-1,-1), colors.HexColor("#FFFFFF")),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.HexColor("#FFFFFF"), colors.HexColor("#F8FAFC")]),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#CBD5E1")),
        ('FONTSIZE', (0,1), (-1,-1), 8),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('TOPPADDING', (0,1), (-1,-1), 4),
        ('BOTTOMPADDING', (0,1), (-1,-1), 4),
    ]))
    story.append(t_matrix)
    story.append(Spacer(1, 15))

    # 2. BODY PART - DESIGN PATTERN ANALYSIS
    story.append(Paragraph("2. Body Part — Architectural Implementation of Design Patterns", h1_style))
    
    # 2.1 Factory Method
    story.append(Paragraph("2.1 Factory Method Pattern (Creational) — AinurSarsenbai", h2_style))
    story.append(Paragraph(
        "<b>Intent & Problem:</b> The catalog holds heterogeneous products with different domain rules. "
        "Direct instantiation via constructors leads to tight coupling. Factory Method delegates object creation to specialized creator subclasses.",
        body_style
    ))
    story.append(Paragraph(
        "<b>Implementation:</b> <code>ProductFactory</code> defines abstract <code>createProduct()</code>. "
        "Concrete creators (<code>ElectronicsFactory</code>, <code>ClothingFactory</code>, <code>BookFactory</code>, <code>DigitalProductFactory</code>) "
        "initialize domain-specific fields (weights, dimensions, license keys) and calculate category taxes. "
        "<code>ProductCatalogRegistry</code> centralizes factory access.",
        body_style
    ))

    # 2.2 Builder
    story.append(Paragraph("2.2 Builder Pattern (Creational) — Eqziz", h2_style))
    story.append(Paragraph(
        "<b>Intent & Problem:</b> Assembling customizable hardware (e.g. Gaming PCs, Student Workstations) involves complex telescoping constructors. "
        "Builder separates the construction of a complex object from its representation.",
        body_style
    ))
    story.append(Paragraph(
        "<b>Implementation:</b> <code>ProductBuilder</code> declares fluent configuration steps. "
        "<code>CustomProductBuilder</code> tracks incremental component additions (CPU, RAM, GPU, SSD, OS) and dynamically sums addon costs. "
        "<code>ProductDirector</code> encapsulates predefined assembly sequences (e.g., <code>constructGamingPc()</code>).",
        body_style
    ))

    # 2.3 Observer
    story.append(Paragraph("2.3 Observer Pattern (Behavioral) — baktiyarovamereilim-lang", h2_style))
    story.append(Paragraph(
        "<b>Intent & Problem:</b> Multiple stakeholders require notification when stock drops or prices change. Tight coupling between inventory and external services violates the Open/Closed Principle.",
        body_style
    ))
    story.append(Paragraph(
        "<b>Implementation:</b> <code>Subject</code> and <code>Observer</code> define the publish-subscribe contract. "
        "<code>InventorySubject</code> monitors stock levels and product prices. When stock drops below the critical threshold (<=3), "
        "it notifies <code>WarehouseInventoryObserver</code>. When prices decrease, <code>CustomerAlertObserver</code> dispatches deal alerts. "
        "<code>AnalyticsAuditObserver</code> chronologically records all transitions.",
        body_style
    ))

    story.append(PageBreak())

    # 2.4 Strategy
    story.append(Paragraph("2.4 Strategy Pattern (Behavioral) — Eqziz", h2_style))
    story.append(Paragraph(
        "<b>Intent & Problem:</b> E-commerce stores offer constantly shifting promotional rules. Hardcoding if-else trees in cart calculation violates OCP and Single Responsibility.",
        body_style
    ))
    story.append(Paragraph(
        "<b>Implementation:</b> <code>DiscountStrategy</code> defines <code>applyDiscount(subtotal, items, customerTier)</code>. "
        "Pluggable strategies include: <code>PercentageDiscountStrategy</code>, <code>FlatRateDiscountStrategy</code>, "
        "<code>TieredLoyaltyDiscountStrategy</code> (Bronze 3%, Silver 7%, Gold 12%, Platinum 20%), and <code>BuyOneGetOneDiscountStrategy</code>. "
        "Strategies are swappable at runtime in <code>ShoppingCart</code> and <code>CheckoutFacade</code>.",
        body_style
    ))

    # 2.5 Decorator
    story.append(Paragraph("2.5 Decorator Pattern (Structural) — baktiyarovamereilim-lang", h2_style))
    story.append(Paragraph(
        "<b>Intent & Problem:</b> Customers can attach optional value-added services to line items (gift wrap, insurance, express delivery). "
        "Subclassing leads to an exponential class explosion.",
        body_style
    ))
    story.append(Paragraph(
        "<b>Implementation:</b> <code>OrderItem</code> component interface is implemented by <code>StandardOrderItem</code>. "
        "<code>OrderItemDecorator</code> wraps an item and chains dynamic costs and descriptions: "
        "<code>GiftWrapDecorator</code> (+$4.99/unit), <code>ExtendedWarrantyDecorator</code> (10% of base), "
        "<code>ExpressShippingDecorator</code> (+$15.00), and <code>FragileHandlingDecorator</code> (+$10.00).",
        body_style
    ))

    # 2.6 Adapter
    story.append(Paragraph("2.6 Adapter Pattern (Structural) — AinurSarsenbai", h2_style))
    story.append(Paragraph(
        "<b>Intent & Problem:</b> Integrating disparate third-party payment APIs (Stripe charges in integer cents, PayPal token approval, Crypto on-chain hashes) requires an adapter to conform to internal interfaces.",
        body_style
    ))
    story.append(Paragraph(
        "<b>Implementation:</b> <code>PaymentGateway</code> is the internal target interface. "
        "<code>StripePaymentAdapter</code> converts dollars to integer cents and injects idempotency keys. "
        "<code>PayPalPaymentAdapter</code> bridges token creation and capture. "
        "<code>CryptoPaymentAdapter</code> simulates on-chain USDT/Web3 transfer broadcasting.",
        body_style
    ))

    # 2.7 Facade
    story.append(Paragraph("2.7 Facade Pattern (Structural) — AinurSarsenbai", h2_style))
    story.append(Paragraph(
        "<b>Intent & Problem:</b> Order checkout involves coordinating multiple subsystems: stock validation, discount calculation, decorator resolution, payment authorization, and event broadcasting. Client code should not manage this complexity directly.",
        body_style
    ))
    story.append(Paragraph(
        "<b>Implementation:</b> <code>CheckoutFacade</code> encapsulates the complete checkout lifecycle into a single method: "
        "<code>processCheckout(cart, customer, discountStrategy, paymentGateway, decoratedItems)</code>. "
        "It handles validation, atomic stock reservation, rollback upon payment failure, observer notification, and invoice printing.",
        body_style
    ))

    # 3. VERIFICATION & EXECUTION RESULTS
    story.append(Paragraph("3. Verification & Execution Results", h1_style))
    story.append(Paragraph(
        "The system provides 100% test coverage across all seven patterns via <code>TestSuiteRunner</code> "
        "and end-to-end multi-pattern simulation via <code>MilestoneTwoDemo</code> and <code>EcommerceApp</code>.",
        body_style
    ))

    test_results_data = [
        ["Test Suite", "Design Pattern Tested", "Target Classes Verified", "Result"],
        ["FactoryMethodPatternTest", "Factory Method", "ProductCatalogRegistry, Electronics, Digital", "7/7 PASSED"],
        ["BuilderPatternTest", "Builder", "ProductDirector, CustomProductBuilder, CustomProduct", "7/7 PASSED"],
        ["ObserverPatternTest", "Observer", "InventorySubject, Customer, Warehouse, Audit", "7/7 PASSED"],
        ["StrategyPatternTest", "Strategy", "Percentage, FlatRate, LoyaltyTier, BOGO", "7/7 PASSED"],
        ["DecoratorPatternTest", "Decorator", "GiftWrap, Warranty, ExpressShipping, Fragile", "7/7 PASSED"],
        ["AdapterPatternTest", "Adapter", "StripeAdapter, PayPalAdapter, CryptoAdapter", "7/7 PASSED"],
        ["FacadePatternTest", "Facade", "CheckoutFacade, Order, Invoice, InventorySubject", "7/7 PASSED"]
    ]
    t_tests = Table(test_results_data, colWidths=[120, 100, 204, 80])
    t_tests.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#2B6CB0")),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,0), 8),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#CBD5E1")),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor("#F8FAFC")]),
        ('FONTSIZE', (0,1), (-1,-1), 8),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
    ]))
    story.append(t_tests)
    story.append(Spacer(1, 15))

    # 4. CONCLUSION & FURTHER WORK
    story.append(Paragraph("4. Conclusion & Further Work", h1_style))
    story.append(Paragraph(
        "<b>Conclusion:</b> This final project successfully designed, implemented, and verified seven classical design patterns "
        "within a unified, robust E-Commerce Shopping Cart platform in Java 21 LTS. "
        "Each student developer implemented and defended at least two distinct patterns, exceeding the minimum course requirement of six patterns. "
        "The architecture adheres strictly to SOLID principles, high cohesion, low coupling, and clean coding standards.",
        body_style
    ))
    story.append(Paragraph(
        "<b>Further Work:</b> Potential enhancements include integrating persistent relational storage (PostgreSQL/JPA), "
        "exposing RESTful microservices via Spring Boot, and adding WebSocket streaming for live frontend UI updates.",
        body_style
    ))

    doc.build(story, canvasmaker=NumberedCanvas)
    print(f"[ReportLab] Generated academic defense report: {output_filename}")

if __name__ == "__main__":
    create_report()
